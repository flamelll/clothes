<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>删除购物车</title>
	</head>
	<body>
		<center>
			<?php
			include_once ("conn.php");
			if (!($_GET['id'])) {
				echo "输入不允许为空。点击<a href='javascript:onclick=history.go(-1)'>这里</a> 返回";
			} else {
				$name = $_GET['name'];
				$id = $_GET['id'];
				$sqlstr1 = "delete from car where id='$id'";
				$result = mysqli_query($conn, $sqlstr1);
				if ($result) {
					echo '<script>alert("删除成功");location.href="car.php?name=' . $name . '"</script>';
				} else {
					echo "<script>alert('删除失败');history.go(-1);</script>";
				}
			}
			?>
		</center>
	</body>
</html>
