<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    	<!--声明文档兼容模式，表示使用IE浏览器的最新模式-->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--设置视口的宽度(值为设备的理想宽度)，页面初始缩放值<理想宽度/可见宽度>-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->

        <link href="css/bootstrap.min.css" rel="stylesheet">
        <script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery/jquery-1.4.min.js"></script>
    <title>注册</title>
    <script type = "text/javascript">
    $(document).ready(function() {
	$(".register input:first").blur(function() {
		$.ajax({
			type: "post",
			url: "register_user_test.php",
			data: "username=" + $(".register input:first").val(),
			success: function(msg) {
				$("#userinfo").html(msg);
			}
		});
	});
});
    
    </script>
    <style type="text/css">
        body{
            background: url("img/watercolor.png");
            background-repeat: no-repeat;
            background-size:cover;
        }
 #mydiv{   
     margin:0 auto;   
     width:800px;   
     height:800px; 

 }
 fieldset{padding:.35em .625em .75em;margin:0 2px;border:3px solid black}
legend{padding:.5em;border:0;width:auto}

.reginfo {
	width: 150px;
	height: 60px;
	float: left;
	margin-right: 20px;
	color: #999999;
	font-size: 13px;
	line-height: 30px;
}
    </style>
</head>
<body>

    <div id="mydiv" >
        <form class="form-horizontal" action="register_user.php" method="post">
            <div class="register">
            <fieldset>
                <legend>注册</legend>
                <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">账号</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" name="username">
                    </div>
					<div class="reginfo" id="userinfo">
						请输入您的账号.*
					</div>
                  </div>
                  <div class="form-group">
                    <label for="inputPassword3" class="col-sm-2 control-label">密码</label>
                    <div class="col-sm-7">
                      <input type="password" class="form-control" name="password" onblur="checkpwd(this)">
                    </div>
					<div class="reginfo" id="pwds">
						请输入您的密码.*
					</div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">电话</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" name="phone" onblur="checkphone(this)">
                    </div>
					<div class="reginfo" id="userphone">
						请输入您的电话.*
					</div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">地址</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" name="address" onblur="checkaddress(this)" >
                    </div>
					<div class="reginfo" id="useraddress">
						请输入您的地址.
					</div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">邮箱</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" name="email" onblur="checkemail(this)">
                    </div>
					<div class="reginfo" id="useremail">
						请输入您的邮箱.*
					</div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-default">注册</button>
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      &nbsp;&nbsp;&nbsp;
                      <a href="login.php">
						<input type="button" name="submit" size="30" value="返回登录" class="btn btn-default" />
					</a>
                    </div>

                  </div>
        </fieldset>
        </div>
          </form>

    </div>


			<!-- 引入jQuery核心js文件 -->
            <script src="js/jquery-2.1.0.js"></script>
            <!-- 引入BootStrap核心js文件 -->
            <script src="js/bootstrap.js"></script>
</body>
</html>
<script>//检验密码
    function checkpwd(obj) {
        var users = obj.value;
        if(users == "") {
            document.getElementById("pwds").innerHTML = "<font color=red style='font-size:16px;'><b>请填写密码!</b></font>";
            return false;
        } else if(users.length < 6) {
            document.getElementById("pwds").innerHTML = "<font color=red style='font-size:16px;'><b>密码长度不小于六位!</b></font>";
            return false;
        } else {
            document.getElementById("pwds").innerHTML = "";
            return true;
        }
    }
    //检验地址
    function checkaddress(obj) {
        var address = obj.value;
        if(address == "") {
            document.getElementById("useraddress").innerHTML = "<font color=red style='font-size:16px;'><b>请填写地址!</b></font>";
            return false;
        } else {
            document.getElementById("useraddress").innerHTML = "";
            return true;
        }
    }
    
    //检验 手机号码
    function checkphone(obj) {
        var phone = obj.value;
        var test = /^[1][3,4,5,7,8][0-9]{9}$/;
        if(!test.test(phone)) {
            document.getElementById("userphone").innerHTML = "<font color=red style='font-size:16px;'><b>请填写正确的手机号码!</b></font>";
            return false;
        } else {
            document.getElementById("userphone").innerHTML = "";
            return true;
        }
    }
    //检验邮箱
    function checkemail(obj) {
        var email = obj.value;
        var emails = /^[\w\-\.]+@[a-z0-9]+(\-[a-z0-9]+)?(\.[a-z0-9]+(\-[a-z0-9]+)?)*\.[a-z]{2,4}$/i;
        if(emails.test(email)) {
            document.getElementById("useremail").innerHTML = "";
            return true;
        } else {
            document.getElementById("useremail").innerHTML = "<font color=red style='font-size:16px;'><b>请填写正确邮箱地址!</b></font>";
            return true;
        }
    }</script>