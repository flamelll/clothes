<html>
	<head>
	<!--声明文档兼容模式，表示使用IE浏览器的最新模式-->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--设置视口的宽度(值为设备的理想宽度)，页面初始缩放值<理想宽度/可见宽度>-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<title>浏览商品</title>
	</head>
	<script>function del() {
	if(confirm("确定要删除吗？")) {
		return true;
	} else {
		return false;
	}
}</script>
	<style>a {
	text-decoration: none;
        }
        body{
            background: url("img/double-bubble-outline.png");
        }
    </style>
	<body>
		<center>
			<h1>家具信息表</h1>
			<?php
    $name = $_GET['name'];
    if($name=="admin") {
        echo "欢迎您!!".$name;
        echo '&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';
        echo "<a href='addproduct.php?name=$name'>添加商品</a>";
        echo '&nbsp&nbsp&nbsp&nbsp';
        echo "<a href='buy_show.php?name=$name'>查看订单</a>";
        echo '&nbsp&nbsp&nbsp&nbsp';
        echo "<a href='login.php'>退出</a>";
    }else{
        echo "欢迎您!!".$name;
        echo '&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';
        echo "<a href='car.php?name=$name'>查看购物车</a>";
        echo '&nbsp&nbsp&nbsp&nbsp';
        echo "<a href='buy_show.php?name=$name'>查看订单</a>";
        echo '&nbsp&nbsp&nbsp&nbsp';
        echo "<a href='login.php'>退出</a>";
		echo "<form action='search.php' method='post' >
			<input type='text' name='username' id='username' hidden='hidden' value='{$name}' />
			请输入查询商品类型:<input type='text' id='types' name='types'  />
			<input type='submit' value='查询' />
			</form>";
    }
    
    include_once("conn.php");
    
    $pageSize = 10;   //每页显示的数量
  	$rowCount = 0;   //要从数据库中获取
  	$pageNow = 1;    //当前显示第几页
    //如果有pageNow就使用，没有就默认第一页。
  	if (!empty($_GET['pageNow'])){
    $pageNow = $_GET['pageNow'];
  	}
	  	$pageCount = 0;  //表示共有多少页
   
  		$sql1 = "select * from product";
  		$res1 = mysqli_query($conn,$sql1);
   
  		$row1=mysqli_num_rows($res1);
  			//计算共有多少页，ceil取进1
  			$pageCount = ceil(($row1/$pageSize));
    		$pre = ($pageNow-1)*$pageSize;
    ?>
    <table width="799" border="0" cellpadding="5" cellspacing="5">
        <tr>
            <td align="center" valign="middle">
                <?php
				include_once ("conn.php");
                ?>
                <table class="table table-hover table-bordered" border="1" width="500" height="50" align="center" cellpadding="5" cellspacing="0">
                    <thead>
                    <tr>
                        <td width="10%" height="25" class="top">序号</td>
                        <td width="20%" class="top">商品类型</td>
                        <td width="35%" class="top">商品名称</td>
                        <td width="20%" class="top">商品价格</td>
                        <td width="20%" class="top">操作</td>
                    </tr>
                    </thead>
                    <?php
					$sqlstr = "select * from product Limit {$pre},{$pageSize}";
					$result = mysqli_query($conn, $sqlstr);

					while ($rows = mysqli_fetch_row($result)) {
						echo "<tbody><tr>";
						for ($i = 0; $i < count($rows); $i++) {
							echo "<td height='25' align='center' class='m_td'>" . $rows[$i] . "</td>";
						}
						if ($name == "admin") {
							echo "<td class='m_td'><a href='updateproduct.php?id=$rows[0]&ptype=$rows[1]&pname=$rows[2]&price=$rows[3]&name=$name'>修改</a>/<a href='deleteproduct.php?id=$rows[0]&name=$name' onclick='return del();'>删除</a></td>";
						} else {
							echo "<td class='m_td'><a href='addcar.php?name=$name&ptype=$rows[1]&pname=$rows[2]&price=$rows[3]'>添加购物车</a></td>";
						}
						echo "</tr></tbody>";
					}
                    ?>
                </table>
            </td>
        </tr>
        <tr>
        	<td align="center">
        		<?php
				echo '<br><br>';
				echo '<hr>';
				if ($pageNow > 1) {
					$prePage = $pageNow - 1;
					echo "<a href='showproduct.php?pageNow={$prePage}&name={$name}'>上一页</a>&nbsp;";
				}
				if ($pageNow < $pageCount) {
					$nextPage = $pageNow + 1;
					echo "<a href='showproduct.php?pageNow={$nextPage}&name={$name}'>下一页</a>&nbsp;";
					echo "当前页{$pageNow}/共{$pageCount}页";
				}
				echo "<br/><br/>";
			?>
			</td>
			</tr>
			</table>
		</center>
			<!-- 引入jQuery核心js文件 -->
	<script src="js/jquery-2.1.0.js"></script>
	<!-- 引入BootStrap核心js文件 -->
	<script src="js/bootstrap.js"></script>
	</body>
</html>