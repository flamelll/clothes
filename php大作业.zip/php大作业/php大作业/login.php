    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <!--声明文档兼容模式，表示使用IE浏览器的最新模式-->
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--设置视口的宽度(值为设备的理想宽度)，页面初始缩放值<理想宽度/可见宽度>-->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/login.css">
        <title>Document</title>
        <style type="text/css">
            #mydiv{
                margin:0 auto;
                width:600px;
                height:400px;
            }
            fieldset{padding:.35em .625em .75em;margin:0 2px;border:3px solid black}
            legend{padding:.5em;border:0;width:auto}
        </style>
    </head>
    <body>

    <div id="mydiv" >
        <form class="form-horizontal" action="login_user.php" method="post">
            <fieldset>
                <legend>登录</legend>
                <div class="form-group" align="center">
                    <label  class="col-sm-2 control-label">账号</label>
                    <div class="col-sm-10">

                        <input type="text" class="form-control"  placeholder="请输入账号" name="username">
                    </div>
                </div>
                <div class="form-group">
                    <label  class="col-sm-2 control-label">密码</label>
                    <div class="col-sm-10">
                        <input type="password" class="form-control"  placeholder="请输入密码" name="password">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <input type="submit" name="submit" size="30" value="登录" class="btn btn-default" />
                        <a href="register.php">
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;

                            <input type="button" name="submit" size="30" value="注册"  class="btn btn-default"/>
                        </a>
                    </div>
                </div>
            </fieldset>
        </form>

    </div>


    <!-- 引入jQuery核心js文件 -->
    <script src="js/jquery-2.1.0.js"></script>
    <!-- 引入BootStrap核心js文件 -->
    <script src="js/bootstrap.js"></script>
    </body>
    </html>