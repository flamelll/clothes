<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>添加商品</title>
	</head>
	<body>
		<center>
			<?php
			include_once ("conn.php");
			if (!($_POST['ptype'] and $_POST['pname'] and $_POST['price'] and $_POST['id'])) {
				echo "输入不允许为空。点击<a href='javascript:onclick=history.go(-1)'>这里</a> 返回";
			} else {
				$id = $_POST['id'];
				$pname = $_POST['pname'];
				$price = $_POST['price'];
				$name = $_POST['name'];
				$ptype = $_POST['ptype'];

				$sqlstr1 = "update product set pname='$pname',price='$price',ptype='$ptype' where id='$id'";
				$result = mysqli_query($conn, $sqlstr1);
				if ($result) {
					echo '<script>alert("更改成功");location.href="showproduct.php?name=' . $name . '"</script>';
				} else {
					echo "<script>alert('更改失败');history.go(-1);</script>";
				}
			}
			?>
		</center>
	</body>
</html>
