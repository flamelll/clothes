<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>添加商品</title>
	</head>
	<body>
		<center>
			<?php
			include_once ("conn.php");
			if (!($_POST['id']and$_POST['ptype'] and $_POST['pname'] and $_POST['price'] and $_POST['num'] and $_POST['name'] and $_POST['ausername'] and $_POST['tel'] and $_POST['address'] and $_POST['state'])) {
				echo "输入不允许为空。点击<a href='javascript:onclick=history.go(-1)'>这里</a> 返回";
			} else {
                $id = $_POST['id'];
				$ptype = $_POST['ptype'];
				$pname = $_POST['pname'];
				$price = $_POST['price'];
				$num = $_POST['num'];
				$name = $_POST['name'];
				$ausername = $_POST['ausername'];
				$tel = $_POST['tel'];
				$address = $_POST['address'];
				$state = $_POST['state'];
				echo "1." . $ptype . "2." . $pname . "3." . $price . "4." . $num . "5." . $name . "6." . $ausername . "7." . $tel . "8." . $address . "9." . $state;

				$sqlstr1 = "insert into orders (ptype,pname,price,num,ausername,tel,address,state,username) values ('$ptype','$pname','$price','$num','$ausername','$tel','$address','$state','$name')";
				$result = mysqli_query($conn, $sqlstr1);
				if ($result) {
					echo '<script>alert("购买成功！");location.href="showproduct.php?name=' . $name . '"</script>';
				} else {
					echo "<script>alert('购买失败');history.go(-1);</script>";
				}
                $sqlstr1 = "delete from car where id='$id'";
                $result = mysqli_query($conn, $sqlstr1);
			}
			?>
		</center>
	</body>
</html>