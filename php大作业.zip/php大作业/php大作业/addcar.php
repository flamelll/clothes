<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>添加商品</title>
	</head>
	<body>
		<center>
			<?php
			include_once ("conn.php");
			$t = "无";
			$pname = $_GET['pname'];
			$price = $_GET['price'];
			$name = $_GET['name'];
			$ptype = $_GET['ptype'];
			$sqlstr1 = "select * from car where username='$name' and pname='$pname' and ptype='$ptype'";
			$result = mysqli_query($conn, $sqlstr1);
			while ($rows = mysqli_fetch_row($result)) {
				$t = "有";
				$num = $rows[4];
				$num = (int)$num;
				$num = $num + 1;
				$num = (string)$num;
			}
			if ($t == "无") {
				$num = 1;
			}
			echo "num=" . $num;
			echo '<script>location.href="addcar_ok.php?ptype=' . $ptype . '&pname=' . $pname . '&name=' . $name . '&price=' . $price . '&num=' . $num . '"</script>';
			?>
		</center>
	</body>
</html>