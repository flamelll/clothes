<?php
include_once ('conn.php');

$name = $_POST['username'];
$password = $_POST['password'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$email = $_POST['email'];

if ($name == "" || $password == "" || $phone == "" || $email == "") {
	echo "<script>alert('注册失败，请完整填写注册信息');history.go(-1);</script>";

} else {
	$sql = "insert into user(username,password,phone,address,email)values('{$name}','{$password}','{$phone}','{$address}','{$email}')";

	$result = mysqli_query($conn, $sql);

	if ($result) {
		header("refresh:2;url=login.php");
		echo "<script>alert('注册成功,2秒后将返回登录界面');</script>";
	} else {
		echo "<script>alert('添加失败');history.go(-1);</script>";
	}
}
?>