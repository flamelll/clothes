<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
	<!--声明文档兼容模式，表示使用IE浏览器的最新模式-->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--设置视口的宽度(值为设备的理想宽度)，页面初始缩放值<理想宽度/可见宽度>-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
<link href="css/bootstrap.min.css" rel="stylesheet">
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
		<title>添加商品</title>
		<script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery/jquery-1.4.min.js"></script>
		<style type="text/css">* {
	margin: 0px;
	padding: 0px;
}

.register {
	width: 600px;
	height: 400px;
	padding: 25px;
	margin: 20px auto;
	border: 2px solid #7aba5f;
}

.display {
	width: 350px;
	height: 60px;
	float: left;
	margin-right: 20px;
}

.reginfo {
	width: 150px;
	height: 60px;
	float: left;
	margin-right: 20px;
	color: #999999;
	font-size: 13px;
	line-height: 30px;
}

.register input {
	width: 300px;
	height: 30px;
	border: 1px solid #7aba5f;
}

.register input.submit {
	width: 100px;
	height: 40px;
	color: white;
	font-size: 16px;
	background: #7aba5f;
	border: none;
	margin-top: 30px;
	margin-left: 150px;
}
            body{
                background: url("img/double-bubble-outline.png");
            }
        </style>
	</head>
	<body>
		<center>
			<?php
			$name = $_GET['name'];
			?>
			<h1> 添加商品 </h1>
			<form action="addproduct_ok.php" method="post" >
				<input type="hidden" name="name"  value="<?php echo $name; ?>">
				<div class="register">
					<div class="display">
						商品类型:
						<input type="text" name="ptype"  />
					</div>
					<div class="reginfo" id="type">
						请输入商品类型.*
					</div>
					<div class="display">
						商品名称:
						<input type="text" name="pname"  />
					</div>
					<div class="reginfo" id="userinfo">
						请输入商品名称.*
					</div>
					<div class="display">
						商品价格:
						<input type="text" name="price" />
					</div>
					<div class="reginfo" id="pwds">
						请输入商品价格.*
					</div>
					<input type="submit" name="submit" size="30" value="添加" class="submit" />
					<?php
					echo "<a href='showproduct.php?name=$name'><input type='button' name='submit' size='30' value='返回' class='submit' /></a>";
					?>
				</div>
			</form>
		</center>
			<!-- 引入jQuery核心js文件 -->
	<script src="js/jquery-2.1.0.js"></script>
	<!-- 引入BootStrap核心js文件 -->
	<script src="js/bootstrap.js"></script>
	</body>
</html>
