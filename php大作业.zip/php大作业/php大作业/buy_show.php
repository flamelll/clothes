<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>订单信息</title>
	<!--声明文档兼容模式，表示使用IE浏览器的最新模式-->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--设置视口的宽度(值为设备的理想宽度)，页面初始缩放值<理想宽度/可见宽度>-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
<link href="css/bootstrap.min.css" rel="stylesheet">
	</head>
    <style>
        body{
            background: url("img/double-bubble-outline.png");
        }
    </style>

	<body>
		<center>
			<h1>订单信息</h1>
			<?php
			$name = $_GET['name'];
			if ($name == "admin") {
				echo "<a href='addproduct.php?name=$name'>添加商品</a>";
				echo '&nbsp&nbsp&nbsp&nbsp';
				echo "<a href='showproduct.php?name=$name'>返回</a>";
			} else {
				echo "<a href='car.php?name=$name'>查看购物车</a>";
				echo '&nbsp&nbsp&nbsp&nbsp';
				echo "<a href='showproduct.php?name=$name'>继续购物</a>";
			}
			?>
			<table width="799" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" valign="middle">
						<?php
						include_once ("conn.php");
						?>
						<table  class="table table-hover table-bordered" border="1" width="500" height="50" align="center">
							<thead>
								<tr>
									<td class="col-sm-1" width="5%" height="25" class="top">序号</td>
									<td class="col-sm-2" width="30%" class="top">商品类型</td>
									<td class="col-sm-2" width="30%" class="top">商品名称</td>
									<td class="col-sm-1" width="30%" class="top">商品价格</td>
									<td class="col-sm-1" width="30%" class="top">购买数量</td>
									<td class="col-sm-1" width="30%" class="top">收件人</td>
									<td class="col-sm-1" width="30%" class="top">收件电话</td>
									<td class="col-sm-1" width="30%" class="top">收件地址</td>
									<td class="col-sm-1" width="30%" class="top">物流信息</td>
									<td class="col-sm-1" width="30%" class="top">付款用户</td>
									<td class="col-sm-1" width="30%" class="top">付款</td>

								</tr>
							</thead>
							<?php
							$t = "无";
							if ($name == "admin") {
								$sqlstr = "select * from orders";
							} else {
								$sqlstr = "select * from orders where username= '$name'";
							}
							$result = mysqli_query($conn, $sqlstr);

							while ($rows = mysqli_fetch_row($result)) {
								$t = "有";
								echo "<tbody><tr>";
								for ($i = 0; $i < count($rows); $i++) {
									echo "<td height='25' align='center' class='m_td'>" . $rows[$i] . "</td>";
								}
								$a = (int)$rows[3];
								$b = (int)$rows[4];
								$c = $a * $b;
								echo "<td height='25' align='center' class='m_td'>" . $c . "元</td>";
								if ($name == "admin") {
									echo "<td class='m_td'><a href='updatebuy.php?name=$name&username=$rows[9]&ptype=$rows[1]&pname=$rows[2]&state=$rows[8]'>更改状态</a></td>";
								}
								echo "</tr></tbody>";
							}
							//判断有无订单信息
							if ($t == "无") {
								if ($name == "admin") {
									echo "<tbody><tr>";
									echo "无用户下单。";
									echo "</tr></tbody>";
								} else {
									echo "<tbody><tr>";
									echo "您还没有购买任何商品。";
									echo "</tr></tbody>";
								}
							} else if ($t == "有") {
								if ($name == "admin") {
									echo "<tbody><tr>";
									echo "以下是用户订单信息。";
									echo "</tr></tbody>";
								} else {
									echo "<tbody><tr>";
									echo "以下是您购买的商品。";
									echo "</tr></tbody>";
								}
							}
							?>
						</table></td>
				</tr>
			</table>
		</center>
		<!-- 引入jQuery核心js文件 -->
	<script src="js/jquery-2.1.0.js"></script>
	<!-- 引入BootStrap核心js文件 -->
	<script src="js/bootstrap.js"></script>
	</body>
</html>
