<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>添加商品数量</title>
	</head>
	<body>
		<center>
			<?php
			include_once ("conn.php");
			$t = "无";
			$pname = $_GET['pname'];
			$ptype = $_GET['ptype'];
			$num = $_GET['num'];
			$name = $_GET['name'];
			//减一操作
			$num = (int)$num;
			$num = $num - 1;
			$num = (string)$num;
			$sqlstr1 = "update car set num='$num' where pname='$pname' and username='$name' and ptype='$ptype'";
			$result = mysqli_query($conn, $sqlstr1);
			if ($result) {
				echo '<script>location.href="car.php?name=' . $name . '"</script>';
			} else {
				echo "<script>alert('添加失败');history.go(-1);</script>";
			}
			?>
		</center>
	</body>
</html>

