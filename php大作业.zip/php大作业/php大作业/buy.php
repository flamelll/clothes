<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
	<!--声明文档兼容模式，表示使用IE浏览器的最新模式-->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--设置视口的宽度(值为设备的理想宽度)，页面初始缩放值<理想宽度/可见宽度>-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
<link href="css/bootstrap.min.css" rel="stylesheet">
		<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
		<title>收件人信息</title>
		<script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery/jquery-1.4.min.js"></script>
		<style type="text/css">* {
	margin: 0px;
	padding: 0px;
}

.register {
	width: 600px;
	height: 400px;
	padding: 25px;
	margin: 20px auto;
	border: 2px solid #7aba5f;
}

.display {
	width: 350px;
	height: 60px;
	float: left;
	margin-right: 20px;
}

.reginfo {
	width: 150px;
	height: 60px;
	float: left;
	margin-right: 20px;
	color: #999999;
	font-size: 13px;
	line-height: 30px;
}

.register input {
	width: 300px;
	height: 30px;
	border: 1px solid #7aba5f;
}

.register input.submit {
	width: 100px;
	height: 40px;
	color: white;
	font-size: 16px;
	background: #7aba5f;
	border: none;
	margin-top: 30px;
	margin-left: 150px;
}</style>
	</head>
	<body>
		<center>
			<?php
            $id = $_GET['id'];
			$ptype = $_GET['ptype'];
			$pname = $_GET['pname'];
			$price = $_GET['price'];
			$num = $_GET['num'];
			$name = $_GET['name'];
			$state = "未发货";
			?>
			<h1> 收件人信息 </h1>
			<form action="buy_message.php" method="post" >
                <input type="hidden" name="id"  value="<?php echo $id; ?>">
				<input type="hidden" name="ptype"  value="<?php echo $ptype; ?>">
				<input type="hidden" name="pname"  value="<?php echo $pname; ?>">
				<input type="hidden" name="price"  value="<?php echo $price; ?>">
				<input type="hidden" name="num"  value="<?php echo $num; ?>">
				<input type="hidden" name="name"  value="<?php echo $name; ?>">
				<input type="hidden" name="state"  value="<?php echo $state; ?>">
				<div class="register">
					<div class="display">
						收件人姓名:
						<input type="text" name="ausername"  />
					</div>
					<div class="reginfo" id="auser">
						请输入收件人姓名.*
					</div>
					<div class="display">
						收件人电话:
						<input type="text" name="tel"  />
					</div>
					<div class="reginfo" id="tel">
						请输入收件人电话.*
					</div>
					<div class="display">
						收件人地址:
						<input type="text" name="address" />
					</div>
					<div class="reginfo" id="address">
						请输入收件人地址.*
					</div>
					<input type="submit" name="submit" size="30" value="添加" class="submit" />
					<?php
					echo "<a href='car.php?name=$name'><input type='button' name='submit' size='30' value='返回' class='submit' /></a>";
					?>
				</div>
			</form>

		</center>
		<!-- 引入jQuery核心js文件 -->
	<script src="js/jquery-2.1.0.js"></script>
	<!-- 引入BootStrap核心js文件 -->
	<script src="js/bootstrap.js"></script>
	</body>
</html>
