<html>
	<head>
	<!--声明文档兼容模式，表示使用IE浏览器的最新模式-->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--设置视口的宽度(值为设备的理想宽度)，页面初始缩放值<理想宽度/可见宽度>-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<title>更改商品</title>
	</head>
	<body>
		<center>

			<h1> 更改商品 </h1>
			<?php
			include_once ("conn.php");
			$id = $_GET['id'];
			$pname = $_GET['pname'];
			$price = $_GET['price'];
			$ptype = $_GET['ptype'];
			$name = $_GET['name'];
			?>
			<form action="updateproduct_ok.php" method="post" >
				<div class="register">
					<input type="hidden" name="id" id="id" value="<?php echo $id; ?>">
					<input type="hidden" name="name"  value="<?php echo $name; ?>">
					<div class="display">
						商品类型:
						<input type="text" name="ptype" value="<?php echo $ptype; ?>"/>
					</div>
					<div class="reginfo" id="ptype">
						请输入商品类型.*
					</div>
					<div class="display">
						商品名称:
						<input type="text" name="pname" value="<?php echo $pname; ?>"/>
					</div>
					<div class="reginfo" id="pname">
						请输入商品名称.*
					</div>
					<div class="display">
						商品价格:
						<input type="text" name="price" value="<?php echo $price; ?>" />
					</div>
					<div class="reginfo" id="price">
						请输入商品价格.*
					</div>

					<input type="submit" name="submit" size="30" value="修改" class="submit" />
				</div>
			</form>
			<?php
			echo "<a href='showproduct.php?name=$name'>返回</a>";
			?>
		</center>
			<!-- 引入jQuery核心js文件 -->
	<script src="js/jquery-2.1.0.js"></script>
	<!-- 引入BootStrap核心js文件 -->
	<script src="js/bootstrap.js"></script>
	</body>
</html>