<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>更改状态</title>
	</head>
	<body>
		<center>
			<?php
			include_once ("conn.php");
			$name = $_GET['name'];
			$username = $_GET['username'];
			$ptype = $_GET['ptype'];
			$pname = $_GET['pname'];
			$state = $_GET['state'];
			if ($state == "未发货") {
				$state = "已发货";
			} else if ($state == "已发货") {
				$state = "待收货";
			} else if ($state == "待收货") {
				$state = "已收货";
			}
			echo "state=" . $state;
			$sqlstr1 = "update orders set state='$state' where username='$username' and ptype='$ptype' and pname='$pname'";
			$result = mysqli_query($conn, $sqlstr1);
			if ($result) {
				echo '<script>location.href="buy_show.php?name=' . $name . '"</script>';
				echo "更改成功";
			} else {
				echo "<script>alert('更改失败');history.go(-1);</script>";
			}
			?>
		</center>
	</body>
</html>
