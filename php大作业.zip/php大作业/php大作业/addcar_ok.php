<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>添加购物车</title>
<!--声明文档兼容模式，表示使用IE浏览器的最新模式-->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--设置视口的宽度(值为设备的理想宽度)，页面初始缩放值<理想宽度/可见宽度>-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
	</head>
	<body>
		<center>
			<?php
			include_once ("conn.php");
			$pname = $_GET['pname'];
			$price = $_GET['price'];
			$ptype = $_GET['ptype'];
			$name = $_GET['name'];
			$num = $_GET['num'];
			$num = (int)$num;
			if ($num > 1) {
				$num = (string)$num;
				$sqlstr1 = "update car set num='$num' where pname='$pname' and username='$name' and ptype='$ptype'";
			} else {
				$num = (string)$num;
				$sqlstr1 = "insert into car (ptype,pname,price,num,username) values ('$ptype','$pname','$price','$num','$name')";
			}
			$result = mysqli_query($conn, $sqlstr1);
			if ($result) {
				echo '<script>alert("添加成功");location.href="showproduct.php?name=' . $name . '"</script>';
			} else {
				echo "<script>alert('添加失败');history.go(-1);</script>";
			}
			?>
		</center>
		<!-- 引入jQuery核心js文件 -->
		<script src="js/jquery-2.1.0.js"></script>
	<!-- 引入BootStrap核心js文件 -->
	<script src="js/bootstrap.js"></script>
	</body>
</html>