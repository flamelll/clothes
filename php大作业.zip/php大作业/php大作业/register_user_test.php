<?php
$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "db_database02";

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn -> connect_error) {
	die("连接失败: " . $conn -> connect_error);
}
$name = $_POST['username'];

$sql = "SELECT * FROM user where username='{$name}'";

$result = mysqli_query($conn, $sql);
$num = mysqli_num_rows($result);
if ($num == 0) {
	echo "";
} else {
	echo "<font color=red style='font-size:16px;'><b>抱歉,无法注册!</b></font>";
}
$conn -> close();
?>