<html>
	<head>
	<!--声明文档兼容模式，表示使用IE浏览器的最新模式-->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--设置视口的宽度(值为设备的理想宽度)，页面初始缩放值<理想宽度/可见宽度>-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<title>购物车</title>
	</head>
	<script>function del() {
	if(confirm("确定要删除吗？")) {
		return true;
	} else {
		return false;
	}
}</script>
<style>
	a{
		text-decoration: none;
	}
    body{
        background: url("img/double-bubble-outline.png");
    }
</style>
	<body>
		<center>
			<h1>购物车</h1>
			<?php
			$name = $_GET['name'];
			echo "<a href='showproduct.php?name=$name'>继续购物</a>";
			echo '&nbsp&nbsp&nbsp&nbsp';
			echo "<a href='emptycar.php?name=$name'>清空购物车</a>";
			?>
			<table width="799" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" valign="middle">
						<?php
						include_once ("conn.php");
						?>
						<table class="table table-hover table-bordered" border="1" width="500" height="50" align="center">
							<thead>
								<tr>
									<td width="5%" height="25" class="top">序号</td>
									<td width="15%" class="top">商品类型</td>
									<td width="15%" class="top">商品名称</td>
									<td width="15%" class="top">商品价格</td>
									<td width="10%" class="top">数量</td>
									<td width="10%" class="top">需支付</td>
									<td width="50%" class="top">操作</td>
								</tr>
							</thead>
							<?php
							$t = "无";
							$p = 0;
							$p = (int)$p;
							$sqlstr = "select * from car where username='$name'";
							$result = mysqli_query($conn, $sqlstr);
							while ($rows = mysqli_fetch_row($result)) {
								$t = "有";
								echo "<tbody><tr>";
								for ($i = 0; $i < count($rows) - 1; $i++) {
									echo "<td height='25' align='center' class='m_td'>" . $rows[$i] . "</td>";
								}
								$a = (int)$rows[3];
								$b = (int)$rows[4];
								$c = $a * $b;
								$p = $p + $c;
								echo "<td height='25' align='center' class='m_td'>" . $c . "元</td>";
								echo "<td class='m_td'><a href='car_increase.php?ptype=$rows[1]&pname=$rows[2]&num=$rows[4]&name=$name'>+</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='car_decrease.php?ptype=$rows[1]&pname=$rows[2]&num=$rows[4]&name=$name'>-</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='deletecar.php?id=$rows[0]&name=$name' onclick='return del();'>删除</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='buy.php?ptype=$rows[1]&pname=$rows[2]&price=$rows[3]&num=$rows[4]&name=$name&id=$rows[0]'>购买</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>";
								echo "</tr></tbody>";
							}
							//判断购物车是否为空
							if ($t == "无") {
								echo "<tbody><tr>";
								echo "您的购物车为空！！快去购物吧！！";
								echo "</tr></tbody>";
							}
							if ($p > 0) {
								echo "购物车商品的总价格为" . $p . "元";
							}
							?>
						</table></td>
				</tr>
			</table>
		</center>
			<!-- 引入jQuery核心js文件 -->
	<script src="js/jquery-2.1.0.js"></script>
	<!-- 引入BootStrap核心js文件 -->
	<script src="js/bootstrap.js"></script>
	</body>
</html>
