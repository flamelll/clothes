<?php
include_once ('conn.php');

$name = $_POST['username'];
$password = $_POST['password'];

echo $name;
echo $password;

if ($name == '' || $password == '') {
	echo "<script>alert('登录失败！请查看是否注册或者输入是否正确！');history.go(-1);</script>";
} else {
	$sql = "SELECT * FROM user where username='{$name}' and password='{$password}'";
	$result = mysqli_query($conn, $sql);
	$num = mysqli_num_rows($result);
	if ($num == 0) {
		echo "<script>alert('登录失败！请检查用户名密码是否正确！');history.go(-1);</script>";
	} else {
		echo '<script>alert("登录成功");location.href="showproduct.php?name=' . $name . '"</script>';
	}
}
?>

