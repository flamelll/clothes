<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>清空购物车</title>
	</head>
	<body>
		<center>
			<?php
			include_once ("conn.php");
			$name = $_GET['name'];

			$sqlstr1 = "delete from car where username='$name'";
			$result = mysqli_query($conn, $sqlstr1);
			if ($result) {
				echo '<script>alert("清空成功");location.href="car.php?name=' . $name . '"</script>';
			} else {
				echo "<script>alert('清空失败');history.go(-1);</script>";
			}
			?>
		</center>
	</body>
</html>