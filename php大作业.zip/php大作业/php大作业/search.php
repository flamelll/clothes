<?php
header("Content-type: text/html; charset=utf-8");
//设置文件编码格式
include_once ('conn.php');

$name = $_POST['username'];
$type = $_POST['types'];
?>

<!DOCTYPE html>
<html>
	<head>
<!--声明文档兼容模式，表示使用IE浏览器的最新模式-->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--设置视口的宽度(值为设备的理想宽度)，页面初始缩放值<理想宽度/可见宽度>-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
<link href="css/bootstrap.min.css" rel="stylesheet">
		<meta charset="UTF-8">
		<title></title>
	</head>
	<style>a {
	text-decoration: none;
}</style>
	<body>
		<center>
			<h1>商品信息表</h1>
			<table width="799" border="0" cellpadding="5" cellspacing="5">
				<tr>
					<td align="center" valign="middle">
						<table class="table table-hover table-bordered" border="1" width="500" height="50" align="center" cellpadding="5" cellspacing="0">
							<thead>
								<tr>
									<td width="10%" height="25" class="top">序号</td>
									<td width="20%" class="top">商品类型</td>
									<td width="35%" class="top">商品名称</td>
									<td width="20%" class="top">商品价格</td>
									<td width="20%" class="top">操作</td>
								</tr>
							</thead>
							<?php
							$sqlstr = "select * from product where ptype='$type'";
							$result = mysqli_query($conn, $sqlstr);

							$row = mysqli_num_rows($result);
							if ($row > 0) {
								while ($rows = mysqli_fetch_row($result)) {
									echo "<tbody><tr>";
									for ($i = 0; $i < count($rows); $i++) {
										echo "<td height='25' align='center' class='m_td'>" . $rows[$i] . "</td>";
									}
									if ($name == "admin") {
										echo "<td class='m_td'><a href='updateproduct.php?id=$rows[0]&ptype=$rows[1]&pname=$rows[2]&price=$rows[3]&name=$name'>修改</a>/<a href='deleteproduct.php?id=$rows[0]&name=$name' onclick='return del();'>删除</a></td>";
									} else {
										echo "<td class='m_td'><a href='addcar.php?name=$name&ptype=$rows[1]&pname=$rows[2]&price=$rows[3]'>添加购物车</a></td>";
									}
									echo "</tr></tbody>";
								}
							} else {
								echo "<script>alert('未查询到该类商品！');history.go(-1);</script>";
							}
							?>
						</table></td>
				</tr>
			</table>
		</center>
			<!-- 引入jQuery核心js文件 -->
	<script src="js/jquery-2.1.0.js"></script>
	<!-- 引入BootStrap核心js文件 -->
	<script src="js/bootstrap.js"></script>
	</body>
</html>
