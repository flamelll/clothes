/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50710
Source Host           : 127.0.0.1:3306
Source Database       : db_database02

Target Server Type    : MYSQL
Target Server Version : 50710
File Encoding         : 65001

Date: 2020-06-09 22:24:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'office', '1234567', '15931829662', '安国', '2248940848@qq.com');
INSERT INTO `user` VALUES ('2', 'hostdirector', '1234567', '15931829662', '安国', '2248940848@qq.com');
INSERT INTO `user` VALUES ('18', 'admin', 'admin', '18312144255', '石家庄', '1342683412@qq.com');
INSERT INTO `user` VALUES ('19', 'salespart', '123456', '18312144255', '石家庄', '1042148223@qq.com');
INSERT INTO `user` VALUES ('21', '20183542', '123456', '18312144255', '广东省', '1342683412@qq.com');
