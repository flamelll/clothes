/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50710
Source Host           : 127.0.0.1:3306
Source Database       : db_database02

Target Server Type    : MYSQL
Target Server Version : 50710
File Encoding         : 65001

Date: 2020-06-09 22:24:13
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ptype` varchar(255) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES ('1', '连衣裙', '连衣裙1', '120');
INSERT INTO `product` VALUES ('2', '卫衣', '卫衣2', '120');
INSERT INTO `product` VALUES ('4', '牛仔裤', '华晨宇的牛仔裤', '80');
INSERT INTO `product` VALUES ('5', '衬衫', '汤姆的汗衫', '60');
INSERT INTO `product` VALUES ('6', '牛仔裤', '加厚牛仔裤', '101');
INSERT INTO `product` VALUES ('7', '袜子', '防狼毛袜', '19.9');
INSERT INTO `product` VALUES ('8', '毛衣', '南极人毛衣', '98.9');
INSERT INTO `product` VALUES ('9', '秋衣秋裤', '保暖又使用的秋衣秋裤', '50');
INSERT INTO `product` VALUES ('10', '风衣', '桐谷和人的掉落风衣 装b指数满分', '999');
INSERT INTO `product` VALUES ('11', '内衣内裤', '内衣', '18');
INSERT INTO `product` VALUES ('12', '运动鞋', '耐克限量版运动鞋', '2499');
