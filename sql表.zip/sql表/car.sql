/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50710
Source Host           : 127.0.0.1:3306
Source Database       : db_database02

Target Server Type    : MYSQL
Target Server Version : 50710
File Encoding         : 65001

Date: 2020-06-09 22:23:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ptype` varchar(255) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `num` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES ('6', '卫衣', '卫衣1', '120', '1', 'salespart');
INSERT INTO `car` VALUES ('7', '连衣裙', '连衣裙1', '120', '2', 'salespart');
INSERT INTO `car` VALUES ('8', '连衣裙', '连衣裙1', '120', '2', 'office');
INSERT INTO `car` VALUES ('9', '卫衣', '卫衣2', '120', '2', 'office');
INSERT INTO `car` VALUES ('10', '牛仔裤', '华晨宇的牛仔裤', '80', '1', 'office');
INSERT INTO `car` VALUES ('12', '衬衫', '汤姆的汗衫', '60', '1', '20183542');
INSERT INTO `car` VALUES ('13', '袜子', '防狼毛袜', '19.9', '1', '20183542');
