/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50710
Source Host           : 127.0.0.1:3306
Source Database       : db_database02

Target Server Type    : MYSQL
Target Server Version : 50710
File Encoding         : 65001

Date: 2020-06-09 22:24:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ptype` varchar(255) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `num` varchar(255) DEFAULT NULL,
  `ausername` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('2', '连衣裙', '连衣裙1', '120', '4', '小刘', '12345678910', '石家庄', '已发货', 'office');
INSERT INTO `orders` VALUES ('3', '衬衫', '汤姆的汗衫', '60', '1', '刘子煜', '18312144288', '石家庄', '待收获', '20183542');
INSERT INTO `orders` VALUES ('4', '袜子', '防狼毛袜', '19.9', '1', '刘子煜', '18312144288', '石家庄', '待收获', '20183542');
